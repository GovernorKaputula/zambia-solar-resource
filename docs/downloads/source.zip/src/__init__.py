"""Zambia solar resource study."""
